import React from 'react';
import ChatApp from './components/ChatApp';

const App = () => <ChatApp />;

export default App;